Everyone is permitted to use, copy, distribute, and modify Pydaptivefiltering python package provided that THE
AUTHORS are cited and the modifications, if they exist, are explained.

THE AUTHORS

  . Bruno Ramos Lima Netto - brunolimanetto@gmail.com & brunoln@cos.ufrj.br
  
  . Guilherme de Oliveira Pinto - guilhermepinto7@gmail.com & guilherme@lps.ufrj.br
  
  . Markus Vinícius Santos Lima - mvsl20@gmail.com & markus@lps.ufrj.br
  
  . Wallace Alves Martins - wallace.wam@gmail.com & wallace@lps.ufrj.br
  
  . Luiz Wagner Pereira Biscainho - cpneqs@gmail.com & wagner@lps.ufrj.br
  
  . Paulo Sergio Ramirez Diniz - diniz@lps.ufrj.br
